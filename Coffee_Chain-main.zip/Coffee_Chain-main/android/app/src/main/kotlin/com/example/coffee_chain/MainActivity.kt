package com.example.coffee_chain

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
