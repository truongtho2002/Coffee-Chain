 class ThongKeKhoModel {
  String? maNVL;
  String? tenNVL;
  String? donViTinh;
  String? soLuongTon; 
  String? slNhap;
  String? slxuat;

  ThongKeKhoModel({
    this.maNVL,
    this.tenNVL,
    this.donViTinh,
    this.soLuongTon, 
    this.slNhap,
    this.slxuat,
  });
}
