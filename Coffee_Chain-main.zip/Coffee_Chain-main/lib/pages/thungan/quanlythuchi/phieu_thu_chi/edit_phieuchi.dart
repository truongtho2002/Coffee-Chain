import 'package:coffee_chain/values/app_colors.dart';
import 'package:flutter/material.dart';

void editphieuchi(BuildContext context, String maPhieu) async {
  return showDialog<void>(
      context: context,
      barrierDismissible: false,
      builder: (BuildContext context) {
        return AlertDialog();
      });
}
