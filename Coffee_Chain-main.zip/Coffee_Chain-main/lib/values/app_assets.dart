class AppAssetImages {
  static String image = 'assets/images/';
  static String logo = '${image}logo.png';
  static String dnerr = '${image}dnerr.png';
}

class AppAssetIcon {
  static String image = 'assets/images/icon/';
  static String iconChuong = '${image}iconChuong.png';
  static String iconExcel = '${image}logo_excel.png';
}
